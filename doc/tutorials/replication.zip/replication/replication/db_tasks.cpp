#include "platform/platform.h"
#include "common/interface/database.h"
#include "common/interface/task.h"
#include "common/lib/tasks_postgresql.h"
#include "common/ilib/json.h"
#include "common/ilib/str.h"
#include "db_tasks.h"

AppTaskDatabaseInit::AppTaskDatabaseInit(IDatabase * database) :
initUsers(database, "users")
{
    this->database = database;
    initUsers.AddColumn("id", "BIGSERIAL PRIMARY KEY NOT NULL");
    initUsers.AddColumn("username", "VARCHAR");
    initUsers.AddColumn("cn", "VARCHAR");
    initUsers.AddConstraint("const_username", "UNIQUE (username)");
}
AppTaskDatabaseInit::~AppTaskDatabaseInit()
{
}
void AppTaskDatabaseInit::Start(class UTask * user)
{
    this->user = user;
    initUsers.Start(this);
}
void AppTaskDatabaseInit::TaskComplete(class ITask * const task)
{
    user->TaskComplete(this);
}
void AppTaskDatabaseInit::TaskFailed(class ITask * const task)
{
    user->TaskFailed(this);
}

void AppTaskDatabaseInit::DatabaseError(IDatabase * const database, db_error_t error)
{
    user->TaskFailed(this);
}

void AppTaskDatabaseInit::DatabaseExecSQLResult(IDatabase * const database, IDataSet * dataset)
{
    delete dataset;
    dataset = 0;
}