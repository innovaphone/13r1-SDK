
/*---------------------------------------------------------------------------*/
/* replication.h                                                               */
/* copyright (c) innovaphone 2015                                            */
/*                                                                           */
/*---------------------------------------------------------------------------*/

class ReplicationService : public AppService {

	class IIoMux * iomux;
    class ISocketProvider * localSocketProvider;
    class IWebserverPluginProvider * webserverPluginProvider;
    class IDatabaseProvider * databaseProvider;

public:
    ReplicationService(class IIoMux * const iomux, class ISocketProvider * localSocketProvider, IWebserverPluginProvider * const webserverPluginProvider, class IDatabaseProvider * databaseProvider, AppServiceArgs * args);
    ~ReplicationService();

	class AppInstance * CreateInstance(AppInstanceArgs * args);
    void AppServiceApps(istd::list<AppServiceApp> * appList);
};

typedef std::list<class ReplicationSession *> ReplicationSessionList;
typedef std::list<class HelloWorldSession *> HelloWorldSessionList;
typedef std::list<class PbxApiSampleSession *> PbxApiSampleSessionList;

class Replication : public UWebserverPlugin, public UDatabase, public AppInstance, public UReplicator, public JsonApiContext
{
    class IDatabase * database;
    class IWebserverPlugin * webserverPlugin;
    bool stopping;
    ReplicationSessionList replicationSessions;

    void WebserverPluginClose(IWebserverPlugin * plugin, wsp_close_reason_t reason, bool lastUser);
    void WebserverPluginHttpListenResult(IWebserverPlugin * plugin, ws_request_type_t requestType, char * resourceName, const char * registeredPathForRequest, ulong64 dataSize);
    void WebserverPluginWebsocketListenResult(IWebserverPlugin * plugin, const char * path, const char * registeredPathForRequest, const char * host);
    void DatabaseConnectComplete(IDatabase * const database);
    void DatabaseShutdown(IDatabase * const database, db_error_t reason);
	void DatabaseError(IDatabase * const database, db_error_t error) {};
    void TryStop();

public:
    Replication(IIoMux * const iomux, ISocketProvider * localSocketProvider, IWebserverPluginProvider * const webserverPluginProvider, IDatabaseProvider * databaseProvider, ReplicationService * service, AppInstanceArgs * args);
    ~Replication();
    void Stop();

    class IPbxApi * pbx;
    const char * GetAppPassword();
    void ReplicationSessionClosed(ReplicationSession * session);

    void ReplicatorInitialized();
    void ReplicatorAdded(ulong64 id);
    void ReplicatorDeleted(ulong64 id);
    void ReplicatorDeletedConfirm(ulong64 id);
    void ReplicatorDeletedConfirmComplete(ulong64 id);
    void ReplicatorUpdated(ulong64 id, ulong64 mask);
    void ReplicatorUpdate(class json_io & msg, word base, bool initial);
    void ReplicatorStopped();
    void ReplicatorStart(class json_io & msg, word base, char * & tmp) override;

    class IReplicator * replicator;

    class ITask * tableSetup;

    void DatabaseInitComplete(class TaskDatabaseInit * task);
    void DatabaseInitFailed(class TaskDatabaseInit * task);
    class UTaskTemplate<Replication, class TaskDatabaseInit> taskDatabaseInit;

};


class ReplicationSession : public AppWebsocket {
    class Replication * replicationInstance;
    class IPbxApi * pbx;
    bool closing;
    bool appWebsocketClosed;

    char * AppWebsocketPassword();
    void AppWebsocketMessage(class json_io & msg, word base, const char * mt, const char * src);
    void AppWebsocketClosed();
    void AppWebsocketSendResult() {};
    void TryClose();

public:
    ReplicationSession(class Replication * replicationInstance, class IWebserverPlugin * webserverPlugin);
    ~ReplicationSession();

    void Close();
};

