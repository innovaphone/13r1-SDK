﻿
var sdksample = sdksample || {};
sdksample.pbxpresenceLang = {
    sip: "SIP",
    presence: "Presence",
    setActivity: "Set activity"
}
