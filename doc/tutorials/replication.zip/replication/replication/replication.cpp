
/*---------------------------------------------------------------------------*/
/* replication.cpp                                                             */
/* copyright (c) innovaphone 2016                                            */
/*                                                                           */
/*---------------------------------------------------------------------------*/

#include "platform/platform.h"
#include "common/os/iomux.h"
#include "common/interface/socket.h"
#include "common/interface/webserver_plugin.h"
#include "common/interface/database.h"
#include "common/interface/task.h"
#include "common/interface/json_api.h"
#include "common/interface/pbx.h"
#include "common/interface/replication.h"
#include "common/ilib/json.h"
#include "common/lib/appservice.h"
#include "common/lib/appwebsocket.h"
#include "common/lib/tasks_postgresql.h"
#include "db_tasks.h"
#include "replication.h"

/*---------------------------------------------------------------------------*/
/*---------------------------------------------------------------------------*/

ReplicationService::ReplicationService(class IIoMux * const iomux, class ISocketProvider * localSocketProvider, class IWebserverPluginProvider * const webserverPluginProvider, class IDatabaseProvider * databaseProvider, AppServiceArgs * args) : AppService(iomux, localSocketProvider, args)
{
    this->iomux = iomux;
    this->localSocketProvider = localSocketProvider;
    this->webserverPluginProvider = webserverPluginProvider;
    this->databaseProvider = databaseProvider;
}

ReplicationService::~ReplicationService()
{

}

class AppInstance * ReplicationService::CreateInstance(AppInstanceArgs * args)
{
    return new Replication(iomux, localSocketProvider, webserverPluginProvider, databaseProvider, this, args);
}

void ReplicationService::AppServiceApps(istd::list<AppServiceApp> * appList)
{
    appList->push_back(new AppServiceApp("helloworld"));
    appList->push_back(new AppServiceApp("pbx-presence"));
}

/*---------------------------------------------------------------------------*/
/*---------------------------------------------------------------------------*/

Replication::Replication(IIoMux * const iomux, ISocketProvider * localSocketProvider, IWebserverPluginProvider * const webserverPluginProvider, IDatabaseProvider * databaseProvider, class ReplicationService * service, AppInstanceArgs * args) : 
AppInstance(service, args),
taskDatabaseInit(this, &Replication::DatabaseInitComplete, &Replication::DatabaseInitFailed)
{
    this->stopping = false;
    this->webserverPlugin = webserverPluginProvider->CreateWebserverPlugin(iomux, localSocketProvider, this, args->webserver, args->webserverPath, this);
    this->database = databaseProvider->CreateDatabase(iomux, this, this);
    this->database->Connect(args->dbHost, args->dbName, args->dbUser, args->dbPassword);
    this->pbx = 0;
    Log("App instance started");

    replicator = IReplicator::createReplicator(this, "PbxTableUsers", 0, 0, "domain", "pbx", database, "users", true, true);
    RegisterJsonApi(replicator);
    replicator->AddColumn("h323", "username", ReplicationString, true);
    replicator->AddColumn("cn", "cn", ReplicationString, true);
}

Replication::~Replication()
{
}

void Replication::Stop()
{
    TryStop();
}

void Replication::TryStop()
{
    stopping = true;
    if (replicationSessions.size() > 0) {
        for (ReplicationSessionList::iterator sessionItr = replicationSessions.begin(); sessionItr != replicationSessions.end(); sessionItr++) {
            (*sessionItr)->Close();
        }
        return;
    }
    if (webserverPlugin) {
        webserverPlugin->Close();
        return;
    }
    if (database) {
        database->Shutdown();
        return;
    }
    appService->AppStopped(this);
}

const char * Replication::GetAppPassword()
{
    return this->args.appPassword;
}

void Replication::ReplicationSessionClosed(ReplicationSession * session)
{
    replicationSessions.remove(session);
    delete session;
    if (stopping) TryStop();
}

/* Webserver plugin */

void Replication::WebserverPluginClose(IWebserverPlugin * plugin, wsp_close_reason_t reason, bool lastUser)
{
    Log("WebserverPlugin closed");
    delete webserverPlugin;
    webserverPlugin = 0;
    TryStop();
}

void Replication::WebserverPluginHttpListenResult(IWebserverPlugin * plugin, ws_request_type_t requestType, char * resourceName, const char * registeredPathForRequest, ulong64 dataSize)
{
    Log("Replication::WebserverHttpListenResult path=%s", resourceName);
    if (requestType == WS_REQUEST_GET) {
        if (plugin->BuildRedirect(resourceName, _BUILD_STRING_, strlen(_BUILD_STRING_))) {
            return;
        }
    }
    plugin->Cancel(WSP_CANCEL_NOT_FOUND);
}

void Replication::WebserverPluginWebsocketListenResult(IWebserverPlugin * plugin, const char * path, const char * registeredPathForRequest, const char * host)
{
    Log("Replication::WebserverWebsocketListenResult path=%s", path);
    if (stopping) {
        plugin->Cancel(WSP_CANCEL_UNAVAILABLE);
        return;
    }
    replicationSessions.push_back(new ReplicationSession(this, plugin));
}

/* Database connection */

void Replication::DatabaseConnectComplete(IDatabase * const database)
{
    Log("Replication::DatabaseConnectComplete");
    this->tableSetup = new AppTaskDatabaseInit(database);
    this->tableSetup->Start(&taskDatabaseInit);
}

void Replication::DatabaseInitComplete(class TaskDatabaseInit * task)
{
    replicator->Initialize("BIGINT REFERENCES users(id) ON DELETE CASCADE NOT NULL");
}
void Replication::DatabaseInitFailed(class TaskDatabaseInit * task)
{

}
void Replication::DatabaseShutdown(IDatabase * const database, db_error_t reason)
{
    Log("Database closed");
    delete this->database;
    this->database = 0;
    TryStop();
}

void Replication::ReplicatorInitialized()
{
    Log("Replication::ReplicatorInitialized");
    this->webserverPlugin->HttpListen(0, 0, 0, 0, _BUILD_STRING_);
    this->webserverPlugin->WebsocketListen();
    replicator->Update(args.appDomain, "master");
}

void Replication::ReplicatorAdded(ulong64 id)
{
}

void Replication::ReplicatorDeleted(ulong64 id)
{
    replicator->DeletedConfirm(id);
}

void Replication::ReplicatorDeletedConfirm(ulong64 id)
{
}

void Replication::ReplicatorDeletedConfirmComplete(ulong64 id)
{
}

void Replication::ReplicatorUpdated(ulong64 id, ulong64 mask)
{
}

void Replication::ReplicatorUpdate(class json_io & msg, word base, bool initial)
{
}

void Replication::ReplicatorStopped()
{
    delete replicator;
    replicator = 0;
    TryStop();
}

void Replication::ReplicatorStart(class json_io & msg, word base, char * & tmp)
{
    Log("Replication::ReplicatorStart");
    word handle = msg.add_array(base, "pseudo");
    msg.add_string(handle, nullptr, "");
    msg.add_string(handle, nullptr, "executive");
}

/*---------------------------------------------------------------------------*/
/*---------------------------------------------------------------------------*/

ReplicationSession::ReplicationSession(class Replication * replicationInstance, class IWebserverPlugin * webserverPlugin) : AppWebsocket(webserverPlugin, replicationInstance)
{
    this->replicationInstance = replicationInstance;
    this->pbx = 0;
    this->closing = false;
    this->appWebsocketClosed = false;
}

ReplicationSession::~ReplicationSession()
{
    TEST_WATCH("_ReplicationSession");
    if (pbx) {
        if (replicationInstance->pbx == pbx) replicationInstance->pbx = 0;
        delete pbx;
        pbx = 0;
    }
}

char * ReplicationSession::AppWebsocketPassword()
{
    return (char *)replicationInstance->GetAppPassword();
}

void ReplicationSession::AppWebsocketMessage(class json_io & msg, word base, const char * mt, const char * src)
{
    if (!strcmp(mt, "PbxInfo")) {
        if (!strcmp(app, "helloworld")){
            class JsonApi * jsonApi = replicationInstance->CreateJsonApi("PbxTableUsers", this, msg, base);
            if (jsonApi) jsonApi->JsonApiStart();
        }
        AppWebsocketMessageComplete();
    }
    else {
        AppWebsocketMessageComplete();
    }
}

void ReplicationSession::AppWebsocketClosed()
{
    this->appWebsocketClosed = true;
    TryClose();
}

void ReplicationSession::TryClose()
{
    this->closing = true;
    if (!this->appWebsocketClosed) {
        this->AppWebsocketClose();
        return;
    }
    replicationInstance->ReplicationSessionClosed(this);
}

void ReplicationSession::Close()
{
    TryClose();
}
