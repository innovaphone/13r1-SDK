﻿
var sdksample = sdksample || {};
sdksample.pbxpresenceLang = {
    sip: "SIP",
    presence: "Anwesenheit",
    setActivity: "Aktivität setzen"
}
