﻿
var sdksample = sdksample || {};
sdksample.helloworldLang = {
    hello: "Hello!"
}
