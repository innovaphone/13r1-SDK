class AppTaskDatabaseInit : public ITask, public UTask, public UDatabase {
    class TaskPostgreSQLInitTable initUsers;
    IDatabase * database;

    void TaskComplete(class ITask * const task);
    void TaskFailed(class ITask * const task);
    void DatabaseError(IDatabase * const database, db_error_t error);
    void DatabaseExecSQLResult(IDatabase * const database, IDataSet * dataset);

public:
    AppTaskDatabaseInit(IDatabase * database);
    virtual ~AppTaskDatabaseInit();
    void Start(class UTask * user);
};