
class HelloWorldSession : public AppWebsocket{
    class Replication * appInstance;

    bool closing;
    bool appWebsocketClosed;

    char * AppWebsocketPassword();
    void AppWebsocketMessage(class json_io & msg, word base, const char * mt, const char * src);
    void AppWebsocketClosed();
    void AppWebsocketSendResult() {};

    void TryClose();

public:
    HelloWorldSession(class Replication * appInstance, class IWebserverPlugin * webserverPlugin);
    ~HelloWorldSession();

    void Close();
};
